uint8_t InitTapeFollowSubHSM(void);

uint8_t AlternativeInitTapeFollowSubHSM(void);

ES_Event RunTapeFollowSubHSM(ES_Event ThisEvent);