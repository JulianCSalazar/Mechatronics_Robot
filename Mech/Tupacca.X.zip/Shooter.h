#include "pwm.h"
#include "IO_Ports.h"

void Shooter_Init(void);
void Shooter_On(int);
void Shooter_Off(void);


