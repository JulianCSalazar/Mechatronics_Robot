/* 
 * File:   EvadeSubHSM.h
 * Author: jucsalaz
 *
 * Created on December 1, 2017, 3:47 AM
 */

#ifndef EVADESUBHSM_H
#define	EVADESUBHSM_H

uint8_t InitEvadeSubHSM(void);

ES_Event RunEvadeSubHSM(ES_Event ThisEvent);

#endif	/* EVADESUBHSM_H */

