/* 
 * File:   OrientationSubHSM.h
 * Author: jucsalaz
 *
 * Created on December 1, 2017, 3:45 AM
 */

#ifndef ORIENTATIONSUBHSM_H
#define	ORIENTATIONSUBHSM_H

uint8_t InitOrientationSubHSM(void);

ES_Event RunOrientationSubHSM(ES_Event ThisEvent);

#endif	/* ORIENTATIONSUBHSM_H */

