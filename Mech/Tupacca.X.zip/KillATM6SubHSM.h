/* 
 * File:   KillATM6SubHSM.h
 * Author: jucsalaz
 *
 * Created on December 1, 2017, 3:46 AM
 */

#ifndef KILLATM6SUBHSM_H
#define	KILLATM6SUBHSM_H

uint8_t InitKillATM6SubHSM(void);

uint8_t AlternateInitKillATM6SubHSM(void);

ES_Event RunKillATM6SubHSM(ES_Event ThisEvent);

#endif	/* KILLATM6SUBHSM_H */

