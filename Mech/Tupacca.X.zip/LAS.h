void LAS_Init(void);

void LAS_Retract(void);

void LAS_Extend(void);