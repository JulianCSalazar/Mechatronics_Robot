/* 
 * File:   Beacon.h
 * Author: rkgrant
 *
 * Created on November 26, 2017, 9:12 PM
 */

#ifndef BEACON_H
#define	BEACON_H

void Beacon_Init(void);

unsigned int Beacon_Read(void);

#endif	/* BEACON_H */

