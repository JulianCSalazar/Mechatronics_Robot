/*
  
 Library for use with front tape sensor.
 Returns Black or White depending on the object in front of Julian, The Robot Who Loves.
 
 */




void InitFrontTape(void);
int ReadObject(void);





