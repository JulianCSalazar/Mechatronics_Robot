/* 
 * File:   TWD.h
 * Author: jucsalaz
 *
 * Created on November 27, 2017, 1:56 AM
 */


#ifndef TWD_H
#define	TWD_H


unsigned int TWD_Read(void);

#endif	/* TWD_H */

